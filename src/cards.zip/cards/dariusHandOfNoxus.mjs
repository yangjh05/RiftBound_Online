import { card, DOMAINS } from "./shared.mjs";

export default card({
  id: "OGN-253",
  collectorNumber: "OGN-253/298",
  name: "Darius, Hand of Noxus",
  type: "legend",
  set: "Origins",
  rarity: "Rare",
  domains: [DOMAINS.FURY, DOMAINS.ORDER],
  tags: ["Darius","Reaction"],
  keywords: ["Legion"],
  power: [],
  image: "https://cdn.piltoverarchive.com/cards/OGN-253.webp",
  text: "Tap REACTION, LEGION - ADD 1 (Abilities that add resources can't be reacted to. Get the effect if you've played a card this turn.)",
  effects: [
  {
    "timing": "activated",
    "kind": "showdownEnergy",
    "amount": 1,
    "domains": [
      "Fury",
      "Order"
    ],
    "nonReactive": true,
    "spellOnly": false,
    "requiresLegion": true
  }
]
});
